create extension if not exists pgcrypto;

create table if not exists public.usuarios (
  id uuid primary key default gen_random_uuid(),
  correo text unique not null,
  hash text not null,
  rol text not null default 'tecnico',
  activo boolean not null default true,
  creado_en timestamptz not null default now(),
  mod_en timestamptz not null default now()
);

create index if not exists usuarios_correo_idx on public.usuarios using btree (correo);
