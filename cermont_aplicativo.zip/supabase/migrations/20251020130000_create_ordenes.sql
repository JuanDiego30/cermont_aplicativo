create extension if not exists pgcrypto;

create table if not exists public.clientes (
  id uuid primary key default gen_random_uuid(),
  nombre text not null,
  nit text,
  contacto text,
  telefono text,
  correo text,
  activo boolean not null default true,
  creado_en timestamptz not null default now(),
  mod_en timestamptz not null default now()
);

create index if not exists clientes_nombre_idx on public.clientes using btree (nombre);
create index if not exists clientes_activo_idx on public.clientes using btree (activo);

create table if not exists public.ordenes (
  id uuid primary key default gen_random_uuid(),
  consecutivo text not null unique,
  cliente_id uuid not null references public.clientes (id),
  tipo text not null,
  prioridad text not null,
  titulo text not null,
  descripcion text not null,
  contacto text not null,
  estado text not null default 'NUEVA',
  responsable_id uuid references public.usuarios (id),
  creado_por uuid not null references public.usuarios (id),
  creado_en timestamptz not null default now(),
  mod_en timestamptz not null default now(),
  eliminado_en timestamptz
);

create index if not exists ordenes_estado_idx on public.ordenes using btree (estado);
create index if not exists ordenes_cliente_idx on public.ordenes using btree (cliente_id);
create index if not exists ordenes_creado_en_idx on public.ordenes using btree (creado_en desc);

create table if not exists public.orden_estado_hist (
  id uuid primary key default gen_random_uuid(),
  orden_id uuid not null references public.ordenes (id) on delete cascade,
  estado text not null,
  usuario_id uuid not null references public.usuarios (id),
  nota text,
  responsable_id uuid references public.usuarios (id),
  ts timestamptz not null default now()
);

create index if not exists orden_estado_hist_orden_idx on public.orden_estado_hist using btree (orden_id);
create index if not exists orden_estado_hist_ts_idx on public.orden_estado_hist using btree (ts desc);
