insert into public.clientes (id, nombre, nit, contacto, telefono, correo, activo)
values
  ('11111111-2222-3333-4444-555555555555', 'Cliente Demo Cermont', '900123456-7', 'Laura Delgado', '+57 301 555 2233', 'cliente.demo@cermont.co', true)
on conflict (id)
  do update set
    nombre = excluded.nombre,
    nit = excluded.nit,
    contacto = excluded.contacto,
    telefono = excluded.telefono,
    correo = excluded.correo,
    activo = excluded.activo,
    mod_en = now();
