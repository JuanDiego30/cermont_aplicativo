insert into public.usuarios (correo, hash, rol, activo)
values
  ('admin@cermont.co', '$2b$10$CwTycUXWue0Thq9StjUM0uJ8AV/QXp1S8MaqkOawxYUY8ailqD0Ga', 'admin', true),
  ('tecnico@demo.co', '$2b$10$CwTycUXWue0Thq9StjUM0uJ8AV/QXp1S8MaqkOawxYUY8ailqD0Ga', 'tecnico', true)
on conflict (correo)
  do update set
    hash = excluded.hash,
    rol = excluded.rol,
    activo = excluded.activo,
    mod_en = now();
