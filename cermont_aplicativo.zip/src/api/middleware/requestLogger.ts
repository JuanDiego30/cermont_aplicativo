import type { NextFunction, Request, Response } from 'express';
import { env } from '../config/env';

export function requestLogger(req: Request, res: Response, next: NextFunction) {
  if (env.nodeEnv === 'test') {
    return next();
  }

  const started = Date.now();
  res.on('finish', () => {
    const duration = Date.now() - started;
    const log = `${req.method} ${req.originalUrl} ${res.statusCode} - ${duration}ms`;
    if (env.logLevel === 'debug') {
      console.debug(log);
    } else {
      console.info(log);
    }
  });

  return next();
}
