import { Router } from 'express';
import { z } from 'zod';
import { hashPassword, verifyPassword } from '../utils/password';
import { signToken } from '../utils/jwt';
import { HttpError } from '../middleware/errorHandler';
import { authRequired } from '../middleware/authRequired';
import { createUser, findUserByCorreo, getUserById } from '../services/userService';

const router = Router();

const roleValues = ['admin', 'gerente', 'coordinador', 'tecnico', 'cliente'] as const;

type AllowedRole = (typeof roleValues)[number];

const registerSchema = z.object({
  correo: z.string().email('Correo inválido'),
  password: z.string().min(8, 'La contraseña debe tener al menos 8 caracteres'),
  rol: z.enum(roleValues, {
    errorMap: () => ({ message: 'Rol inválido' }),
  }),
});

const loginSchema = z.object({
  correo: z.string().email('Correo inválido'),
  password: z.string().min(8, 'La contraseña debe tener al menos 8 caracteres'),
});

router.post('/register', async (req, res, next) => {
  try {
    const payload = registerSchema.parse(req.body);

    const existing = await findUserByCorreo(payload.correo);
    if (existing) {
      throw new HttpError(409, 'El correo ya está registrado');
    }

    const hash = await hashPassword(payload.password);
    const user = await createUser({ correo: payload.correo, hash, rol: payload.rol });

    return res.status(201).json({
      id: user.id,
      correo: user.correo,
      rol: user.rol,
    });
  } catch (error) {
    if (error instanceof z.ZodError) {
      return next(new HttpError(422, 'Datos inválidos', error.flatten()));
    }
    return next(error);
  }
});

router.post('/login', async (req, res, next) => {
  try {
    const payload = loginSchema.parse(req.body);
    const user = await findUserByCorreo(payload.correo);

    if (!user) {
      throw new HttpError(401, 'Credenciales inválidas');
    }

    const isValid = await verifyPassword(payload.password, user.hash);
    if (!isValid) {
      throw new HttpError(401, 'Credenciales inválidas');
    }

    const token = signToken({ sub: user.id, correo: user.correo, rol: user.rol as AllowedRole });

    return res.json({
      token,
      user: {
        id: user.id,
        correo: user.correo,
        rol: user.rol,
      },
    });
  } catch (error) {
    if (error instanceof z.ZodError) {
      return next(new HttpError(422, 'Datos inválidos', error.flatten()));
    }
    return next(error);
  }
});

router.get('/users/me', authRequired, async (req, res, next) => {
  try {
    if (!req.user) {
      throw new HttpError(401, 'Autenticación requerida');
    }

    const user = await getUserById(req.user.id);
    if (!user) {
      throw new HttpError(404, 'Usuario no encontrado');
    }

    return res.json({
      id: user.id,
      correo: user.correo,
      rol: user.rol,
    });
  } catch (error) {
    return next(error);
  }
});

export default router;
