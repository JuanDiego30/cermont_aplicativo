import { Router } from 'express';
import { z } from 'zod';
import { authRequired } from '../middleware/authRequired';
import { HttpError } from '../middleware/errorHandler';
import {
  ORDER_PRIORITIES,
  ORDER_STATES,
  ORDER_TYPES,
  type OrderState,
  createOrder,
  getOrderDetail,
  listOrders,
  updateOrder,
} from '../services/orderService';

const router = Router();

const querySchema = z.object({
  estado: z.enum(ORDER_STATES).optional(),
  cliente: z.string().uuid().optional(),
  q: z.string().trim().optional(),
  page: z.coerce.number().int().min(1).optional(),
  pageSize: z.coerce.number().int().min(1).max(100).optional(),
});

const createSchema = z.object({
  cliente_id: z.string().uuid({ message: 'cliente_id inválido' }),
  tipo: z.enum(ORDER_TYPES, { message: 'tipo inválido' }),
  prioridad: z.enum(ORDER_PRIORITIES, { message: 'prioridad inválida' }),
  titulo: z.string().trim().min(3, 'El título es obligatorio'),
  descripcion: z.string().trim().min(10, 'La descripción es obligatoria'),
  contacto: z.string().trim().min(3, 'El contacto es obligatorio'),
});

const patchSchema = z.object({
  estado: z.enum(ORDER_STATES).optional(),
  responsable_id: z.union([z.string().uuid(), z.null()]).optional(),
  nota: z.string().trim().max(1000, 'La nota no puede superar los 1000 caracteres').optional(),
}).refine((data) => data.estado !== undefined || data.responsable_id !== undefined, {
  message: 'Debe enviar al menos estado o responsable_id',
  path: ['estado'],
});

router.use(authRequired);

router.get('/', async (req, res, next) => {
  try {
    const parsed = querySchema.parse(req.query);
    const page = parsed.page ?? 1;
    const pageSize = parsed.pageSize ?? 10;

    const result = await listOrders({
      page,
      pageSize,
      estado: parsed.estado as OrderState | undefined,
      cliente: parsed.cliente,
      q: parsed.q,
    });

    const totalPages = pageSize > 0 ? Math.ceil(result.total / pageSize) : 0;

    return res.json({
      data: result.data,
      pagination: {
        page,
        pageSize,
        total: result.total,
        totalPages,
      },
    });
  } catch (error) {
    if (error instanceof z.ZodError) {
      return next(new HttpError(422, 'Parámetros de consulta inválidos', error.flatten()));
    }
    return next(error);
  }
});

router.post('/', async (req, res, next) => {
  try {
    const body = createSchema.parse(req.body);
    const userId = req.user?.id;
    if (!userId) {
      throw new HttpError(401, 'Autenticación requerida');
    }

    const order = await createOrder(body, userId);
    return res.status(201).json(order);
  } catch (error) {
    if (error instanceof z.ZodError) {
      return next(new HttpError(422, 'Datos inválidos para la orden', error.flatten()));
    }
    return next(error);
  }
});

router.get('/:id', async (req, res, next) => {
  try {
    const { id } = req.params;
    if (!id) {
      throw new HttpError(400, 'ID de la orden requerido');
    }

    const order = await getOrderDetail(id);
    if (!order) {
      throw new HttpError(404, 'Orden no encontrada');
    }

    return res.json(order);
  } catch (error) {
    return next(error);
  }
});

router.patch('/:id', async (req, res, next) => {
  try {
    const { id } = req.params;
    if (!id) {
      throw new HttpError(400, 'ID de la orden requerido');
    }
    const body = patchSchema.parse(req.body);
    const userId = req.user?.id;
    if (!userId) {
      throw new HttpError(401, 'Autenticación requerida');
    }

    const order = await updateOrder(id, body, userId);
    return res.json(order);
  } catch (error) {
    if (error instanceof z.ZodError) {
      return next(new HttpError(422, 'Datos inválidos para la actualización', error.flatten()));
    }
    return next(error);
  }
});

router.post('/:id/evidencias', async (_req, res) => {
  return res.json({ message: 'Endpoint de evidencias pendiente de implementación' });
});

router.post('/:id/informe', async (_req, res) => {
  return res.json({ message: 'Endpoint de informe pendiente de implementación' });
});

export default router;
