import fs from 'node:fs';
import path from 'node:path';
import { config as loadEnv } from 'dotenv';

const candidatePaths = [
  process.env.API_ENV_FILE,
  process.env.BACKEND_ENV_FILE,
  path.resolve(process.cwd(), 'src/api/.env'),
  path.resolve(process.cwd(), '.env'),
].filter((p): p is string => Boolean(p));

for (const filePath of [...new Set(candidatePaths)]) {
  if (fs.existsSync(filePath)) {
    loadEnv({ path: filePath });
  }
}

const requiredKeys = [
  'SUPABASE_URL',
  'SUPABASE_ANON_KEY',
  'SUPABASE_SERVICE_ROLE_KEY',
  'JWT_SECRET',
];

const missing = requiredKeys.filter((key) => !process.env[key]);
if (missing.length > 0) {
  throw new Error(
    `Variables de entorno faltantes para el backend: ${missing.join(', ')}`,
  );
}

export const env = {
  nodeEnv: process.env.NODE_ENV ?? 'development',
  port: Number(process.env.PORT ?? 4000),
  frontendOrigin: process.env.FRONTEND_ORIGIN ?? 'http://localhost:3000',
  supabaseUrl: process.env.SUPABASE_URL!,
  supabaseAnonKey: process.env.SUPABASE_ANON_KEY!,
  supabaseServiceRoleKey: process.env.SUPABASE_SERVICE_ROLE_KEY!,
  logLevel: process.env.LOG_LEVEL ?? 'info',
  jwtSecret: process.env.JWT_SECRET!,
} as const;

export type Env = typeof env;
