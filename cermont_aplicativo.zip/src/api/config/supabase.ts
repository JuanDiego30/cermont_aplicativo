import { createClient, type SupabaseClient } from '@supabase/supabase-js';
import { env } from './env';

const clientOptions = {
  auth: {
    autoRefreshToken: false,
    persistSession: false,
  },
} as const;

export const supabasePublic: SupabaseClient = createClient(
  env.supabaseUrl,
  env.supabaseAnonKey,
  clientOptions,
);

export const supabaseAdmin: SupabaseClient = createClient(
  env.supabaseUrl,
  env.supabaseServiceRoleKey,
  clientOptions,
);
