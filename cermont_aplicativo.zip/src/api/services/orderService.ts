import { supabaseAdmin } from '../config/supabase';
import { HttpError } from '../middleware/errorHandler';

export const ORDER_STATES = ['NUEVA', 'ASIGNADA', 'EN_EJECUCION', 'FINALIZADA', 'CERRADA'] as const;
export type OrderState = (typeof ORDER_STATES)[number];

export const ORDER_PRIORITIES = ['baja', 'normal', 'alta', 'importante', 'uci'] as const;
export type OrderPriority = (typeof ORDER_PRIORITIES)[number];

export const ORDER_TYPES = ['mantenimiento', 'obra', 'cctv'] as const;
export type OrderType = (typeof ORDER_TYPES)[number];

export interface OrderSummary {
  id: string;
  consecutivo: string;
  titulo: string;
  descripcion: string;
  estado: OrderState;
  prioridad: OrderPriority;
  tipo: OrderType;
  cliente: {
    id: string;
    nombre: string;
  } | null;
  responsable: {
    id: string;
    correo: string;
  } | null;
  creado_en: string;
  mod_en: string;
}

export interface OrderHistoryEntry {
  id: string;
  estado: OrderState;
  nota: string | null;
  usuario_id: string;
  responsable_id: string | null;
  ts: string;
  usuario?: {
    id: string;
    correo: string;
    rol?: string;
  } | null;
}

export interface OrderDetail extends OrderSummary {
  cliente_id: string;
  contacto: string;
  historial: OrderHistoryEntry[];
}

export interface ListOrdersOptions {
  page: number;
  pageSize: number;
  estado?: OrderState;
  cliente?: string;
  q?: string;
}

export interface ListOrdersResult {
  data: OrderSummary[];
  total: number;
}

export interface CreateOrderInput {
  cliente_id: string;
  tipo: OrderType;
  prioridad: OrderPriority;
  titulo: string;
  descripcion: string;
  contacto: string;
}

export interface UpdateOrderInput {
  estado?: OrderState;
  responsable_id?: string | null;
  nota?: string | null;
}

const ORDER_TRANSITIONS: Record<OrderState, OrderState[]> = {
  NUEVA: ['ASIGNADA'],
  ASIGNADA: ['EN_EJECUCION'],
  EN_EJECUCION: ['FINALIZADA'],
  FINALIZADA: ['CERRADA'],
  CERRADA: [],
};

async function generateConsecutivo(): Promise<string> {
  const year = new Date().getFullYear();
  const prefix = `ORD-${year}-`;

  const { data, error } = await supabaseAdmin
    .from('ordenes')
    .select('consecutivo')
    .ilike('consecutivo', `${prefix}%`)
    .order('consecutivo', { ascending: false })
    .limit(1);

  if (error) {
    throw new HttpError(500, 'No se pudo generar consecutivo de la orden', error.message);
  }

  const last = data?.[0]?.consecutivo as string | undefined;
  const lastNumber = last ? Number.parseInt(last.replace(prefix, ''), 10) : 0;
  const nextNumber = Number.isNaN(lastNumber) ? 1 : lastNumber + 1;
  const padded = nextNumber.toString().padStart(6, '0');
  return `${prefix}${padded}`;
}

function mapOrder(row: any): OrderSummary {
  return {
    id: row.id,
    consecutivo: row.consecutivo,
    titulo: row.titulo,
    descripcion: row.descripcion,
    estado: row.estado,
    prioridad: row.prioridad,
    tipo: row.tipo,
    cliente: row.cliente ? { id: row.cliente.id, nombre: row.cliente.nombre } : null,
    responsable: row.responsable
      ? { id: row.responsable.id, correo: row.responsable.correo }
      : null,
    creado_en: row.creado_en,
    mod_en: row.mod_en,
  };
}

function mapOrderDetail(row: any): OrderDetail {
  const base = mapOrder(row);
  const historial: OrderHistoryEntry[] = Array.isArray(row.historial)
    ? row.historial
        .map((entry: any) => ({
          id: entry.id,
          estado: entry.estado,
          nota: entry.nota ?? null,
          usuario_id: entry.usuario_id,
          responsable_id: entry.responsable_id ?? null,
          ts: entry.ts,
          usuario: entry.usuario
            ? {
                id: entry.usuario.id,
                correo: entry.usuario.correo,
                rol: entry.usuario.rol,
              }
            : null,
        }))
        .sort((a, b) => new Date(b.ts).getTime() - new Date(a.ts).getTime())
    : [];

  return {
    ...base,
    cliente_id: row.cliente_id,
    contacto: row.contacto,
    historial,
  };
}

export async function listOrders(options: ListOrdersOptions): Promise<ListOrdersResult> {
  const offset = (options.page - 1) * options.pageSize;

  let query = supabaseAdmin
    .from('ordenes')
    .select(
      `id, consecutivo, cliente_id, tipo, prioridad, titulo, descripcion, estado, contacto, responsable_id, creado_por, creado_en, mod_en,
       cliente:cliente_id (id, nombre),
       responsable:responsable_id (id, correo)`,
      { count: 'exact' },
    )
    .is('eliminado_en', null)
    .order('creado_en', { ascending: false })
    .range(offset, offset + options.pageSize - 1);

  if (options.estado) {
    query = query.eq('estado', options.estado);
  }

  if (options.cliente) {
    query = query.eq('cliente_id', options.cliente);
  }

  if (options.q) {
    const like = options.q.trim();
    if (like) {
      query = query.or(`titulo.ilike.%${like}%,descripcion.ilike.%${like}%`);
    }
  }

  const { data, error, count } = await query;

  if (error) {
    throw new HttpError(500, 'No se pudieron listar las órdenes', error.message);
  }

  return {
    data: (data ?? []).map(mapOrder),
    total: count ?? 0,
  };
}

export async function getOrderDetail(id: string): Promise<OrderDetail | null> {
  const { data, error } = await supabaseAdmin
    .from('ordenes')
    .select(
      `id, consecutivo, cliente_id, tipo, prioridad, titulo, descripcion, estado, contacto, responsable_id, creado_por, creado_en, mod_en,
       cliente:cliente_id (id, nombre),
       responsable:responsable_id (id, correo, rol),
       historial:orden_estado_hist (id, estado, nota, usuario_id, responsable_id, ts, usuario:usuario_id (id, correo, rol))`
    )
    .eq('id', id)
    .is('eliminado_en', null)
    .maybeSingle();

  if (error) {
    throw new HttpError(500, 'No se pudo obtener la orden', error.message);
  }

  if (!data) {
    return null;
  }

  return mapOrderDetail(data);
}

async function insertHistoryEntry(payload: {
  orden_id: string;
  estado: OrderState;
  usuario_id: string;
  nota?: string | null;
  responsable_id?: string | null;
}) {
  const { error } = await supabaseAdmin
    .from('orden_estado_hist')
    .insert({
      orden_id: payload.orden_id,
      estado: payload.estado,
      usuario_id: payload.usuario_id,
      nota: payload.nota ?? null,
      responsable_id: payload.responsable_id ?? null,
    });

  if (error) {
    throw new HttpError(500, 'No se pudo registrar el historial de la orden', error.message);
  }
}

export async function createOrder(payload: CreateOrderInput, userId: string): Promise<OrderDetail> {
  let attempts = 0;
  let consecutivo = await generateConsecutivo();
  const toInsert = {
    consecutivo,
    cliente_id: payload.cliente_id,
    tipo: payload.tipo,
    prioridad: payload.prioridad,
    titulo: payload.titulo,
    descripcion: payload.descripcion,
    contacto: payload.contacto,
    estado: 'NUEVA' as OrderState,
    creado_por: userId,
  };

  while (attempts < 3) {
    const { data, error } = await supabaseAdmin
      .from('ordenes')
      .insert(toInsert)
      .select(
        `id, consecutivo, cliente_id, tipo, prioridad, titulo, descripcion, estado, contacto, responsable_id, creado_por, creado_en, mod_en,
         cliente:cliente_id (id, nombre),
         responsable:responsable_id (id, correo)`
      )
      .single();

    if (error) {
      if (error.code === '23505') {
        attempts += 1;
        consecutivo = await generateConsecutivo();
        toInsert.consecutivo = consecutivo;
        continue;
      }

      if (error.code === '23503') {
        throw new HttpError(400, 'El cliente o responsable indicado no existe', error.message);
      }

      throw new HttpError(500, 'No se pudo crear la orden', error.message);
    }

    if (!data) {
      throw new HttpError(500, 'No se recibió respuesta al crear la orden');
    }

    await insertHistoryEntry({ orden_id: data.id, estado: 'NUEVA', usuario_id: userId, nota: 'Orden creada' });

    const detail = await getOrderDetail(data.id);
    if (!detail) {
      throw new HttpError(500, 'No se pudo obtener la orden recién creada');
    }

    return detail;
  }

  throw new HttpError(409, 'No se pudo generar un consecutivo único para la orden');
}

export async function updateOrder(id: string, payload: UpdateOrderInput, userId: string): Promise<OrderDetail> {
  if (!payload.estado && payload.responsable_id === undefined) {
    throw new HttpError(400, 'No hay cambios para aplicar en la orden');
  }

  const existing = await getOrderDetail(id);
  if (!existing) {
    throw new HttpError(404, 'Orden no encontrada');
  }

  const updates: Record<string, unknown> = {};
  const historyEntries: Array<{ estado: OrderState; nota?: string | null; responsable_id?: string | null }> = [];

  if (payload.estado && payload.estado !== existing.estado) {
    const allowed = ORDER_TRANSITIONS[existing.estado];
    if (!allowed.includes(payload.estado)) {
      throw new HttpError(409, `Transición inválida de ${existing.estado} a ${payload.estado}`);
    }
    updates.estado = payload.estado;
    historyEntries.push({ estado: payload.estado, nota: payload.nota ?? null, responsable_id: existing.responsable?.id ?? null });
  }

  if (payload.responsable_id !== undefined && payload.responsable_id !== existing.responsable?.id) {
    updates.responsable_id = payload.responsable_id;
    const targetState = (updates.estado as OrderState | undefined) ?? existing.estado;
    historyEntries.push({ estado: targetState, nota: payload.nota ?? 'Responsable actualizado', responsable_id: payload.responsable_id ?? null });
  }

  if (Object.keys(updates).length === 0) {
    return existing;
  }

  updates.mod_en = new Date().toISOString();

  const { error } = await supabaseAdmin
    .from('ordenes')
    .update(updates)
    .eq('id', id)
    .is('eliminado_en', null);

  if (error) {
    if (error.code === '23503') {
      throw new HttpError(400, 'Responsable inválido para la orden', error.message);
    }
    throw new HttpError(500, 'No se pudo actualizar la orden', error.message);
  }

  for (const entry of historyEntries) {
    await insertHistoryEntry({
      orden_id: id,
      estado: entry.estado,
      usuario_id: userId,
      nota: entry.nota,
      responsable_id: entry.responsable_id ?? null,
    });
  }

  const detail = await getOrderDetail(id);
  if (!detail) {
    throw new HttpError(500, 'No se pudo obtener la orden actualizada');
  }

  return detail;
}
