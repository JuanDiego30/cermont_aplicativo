import { supabaseAdmin } from '../config/supabase';
import { HttpError } from '../middleware/errorHandler';

export interface UserRecord {
  id: string;
  correo: string;
  hash: string;
  rol: string;
  activo: boolean;
  creado_en: string;
  mod_en: string;
}

export async function findUserByCorreo(correo: string): Promise<UserRecord | null> {
  const { data, error } = await supabaseAdmin
    .from('usuarios')
    .select('*')
    .eq('correo', correo)
    .maybeSingle();

  if (error && error.code !== 'PGRST116') {
    throw new HttpError(500, 'Error consultando usuario por correo', error.message);
  }

  return (data as UserRecord | null) ?? null;
}

export async function createUser(payload: { correo: string; hash: string; rol: string }): Promise<UserRecord> {
  const { data, error } = await supabaseAdmin
    .from('usuarios')
    .insert({
      correo: payload.correo,
      hash: payload.hash,
      rol: payload.rol,
      activo: true,
    })
    .select()
    .single();

  if (error) {
    if (error.code === '23505') {
      throw new HttpError(409, 'El correo ya está registrado');
    }
    throw new HttpError(500, 'Error creando el usuario', error.message);
  }

  return data as UserRecord;
}

export async function getUserById(id: string): Promise<UserRecord | null> {
  const { data, error } = await supabaseAdmin
    .from('usuarios')
    .select('*')
    .eq('id', id)
    .maybeSingle();

  if (error && error.code !== 'PGRST116') {
    throw new HttpError(500, 'Error consultando usuario por id', error.message);
  }

  return (data as UserRecord | null) ?? null;
}

export interface ListUsersOptions {
  page: number;
  limit: number;
  search?: string;
  rol?: string;
  activo?: boolean;
}

export async function listUsers(options: ListUsersOptions) {
  const offset = (options.page - 1) * options.limit;

  let query = supabaseAdmin
    .from('usuarios')
    .select('*', { count: 'exact' })
    .order('creado_en', { ascending: false })
    .range(offset, offset + options.limit - 1);

  if (options.search) {
    query = query.ilike('correo', `%${options.search}%`);
  }

  if (options.rol) {
    query = query.eq('rol', options.rol);
  }

  if (typeof options.activo === 'boolean') {
    query = query.eq('activo', options.activo);
  }

  const { data, error, count } = await query;
  if (error) {
    throw new HttpError(500, 'Error al listar usuarios', error.message);
  }

  return {
    data: (data as UserRecord[] | null) ?? [],
    count: count ?? 0,
  };
}
