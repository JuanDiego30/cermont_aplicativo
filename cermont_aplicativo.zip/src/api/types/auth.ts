export interface AuthUser {
  id: string;
  correo: string;
  rol: string;
}
