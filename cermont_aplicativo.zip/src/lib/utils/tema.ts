// Utilidad para cambiar el tema
export function cambiarTema() {
  document.body.classList.toggle('tema-oscuro');
}
