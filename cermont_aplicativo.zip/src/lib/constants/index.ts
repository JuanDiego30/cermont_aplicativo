/**
 * Barrel export para constantes
 * Centraliza todas las constantes de la aplicación
 */

export * from './routes';
export * from './app-config';
export * from './form-defaults';
