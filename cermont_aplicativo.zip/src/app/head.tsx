import { Metadata } from 'next';

export const metadata: Metadata = {
  title: 'Cermont Web',
  description: 'Welcome to the Cermont Web application',
};