/**
 * Barrel export para componentes compartidos
 * Exporta componentes reutilizables en toda la aplicación
 */

export { default as ThemeToggle } from './ThemeToggle';
